# istack-buddy-utilities

A TypeScript utility library.

## Installation

```bash
npm install istack-buddy-utilities
```

## Usage

```typescript
import { processString } from "istack-buddy-utilities";

const result = processString("  hello  ");
console.log(result); // 'hello'
```

## Development

1. Install dependencies:

```bash
npm install
```

2. Run tests:

```bash
npm test
```

3. Build the project:

```bash
npm run build
```

## Scripts

- `npm run build` - Build the project
- `npm test` - Run tests
- `npm run test:watch` - Run tests in watch mode
- `npm run lint` - Run ESLint
- `npm run clean` - Clean the dist directory
